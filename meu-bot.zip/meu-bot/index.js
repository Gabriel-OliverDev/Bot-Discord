const { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder, InteractionType } = require('discord.js');
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.once('ready', () => {
  console.log(`Bot logado como ${client.user.tag}`);
});

client.on('messageCreate', async message => {
  if (message.author.bot) return;

  // Comando !ping
  if (message.content === '!ping') {
    return message.reply('Pong!');
  }

  // Comando !desconto que usa um botão para abrir um modal de input
  if (message.content === '!desconto') {
    const button = new ButtonBuilder()
      .setCustomId('openDescontoModal')
      .setLabel('Calcular Desconto')
      .setStyle(ButtonStyle.Primary);
    const row = new ActionRowBuilder().addComponents(button);
    return message.channel.send({
      content: '📝 Clique no botão abaixo para calcular o desconto com um formulário:',
      components: [row]
    });
  }
});

client.on('interactionCreate', async interaction => {
  // Ao clicar no botão, abre o modal
  if (interaction.isButton() && interaction.customId === 'openDescontoModal') {
    const modal = new ModalBuilder()
      .setCustomId('descontoModal')
      .setTitle('Calculadora de Descontos');

    const percentInput = new TextInputBuilder()
      .setCustomId('percent')
      .setLabel('Porcentagem (%)')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('Ex: 25')
      .setRequired(true);

    const valueInput = new TextInputBuilder()
      .setCustomId('value')
      .setLabel('Valor original')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('Ex: 1000')
      .setRequired(true);

    const firstRow = new ActionRowBuilder().addComponents(percentInput);
    const secondRow = new ActionRowBuilder().addComponents(valueInput);
    modal.addComponents(firstRow, secondRow);

    return interaction.showModal(modal);
  }

  // Após submissão do modal, calcula e responde com embed
  if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'descontoModal') {
    const perc = parseFloat(interaction.fields.getTextInputValue('percent'));
    const valor = parseFloat(interaction.fields.getTextInputValue('value'));

    if (isNaN(perc) || isNaN(valor)) {
      return interaction.reply({ content: '❌ Valores inválidos. Use apenas números.', ephemeral: true });
    }

    const parte = (perc / 100) * valor;
    const restante = valor - parte;

    const embed = new EmbedBuilder()
      .setTitle('Resultado do Desconto')
      .setColor(0x00FF00)
      .addFields(
        { name: 'Porcentagem', value: `${perc}%`, inline: true },
        { name: 'Valor Original', value: `${valor}`, inline: true },
        { name: 'Valor Descontado', value: `${parte}`, inline: true },
        { name: 'Valor Restante', value: `${restante}`, inline: true }
      );

    return interaction.reply({ embeds: [embed] });
  }
});

client.login('MTM2NDQ0MjI5NjY0MDIwODk1OA.GE39OQ.blpubvieVhVm4w4lJ_V8nyhXOpJSL7z7vfasgA');
